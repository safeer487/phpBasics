<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>enlaces</title>
	<style>
	a{
		width:80px;
		background-color: #e3e3e3;
		text-decoration: none;
		color:black;
		float:left;
		margin-left: 50px;
		text-align: center;

	}
	body{
		margin-left: 50px;
		color:orange;
	}

	form{
		width:200px;
		background-color: #e3e3e3;
	}

	</style>
</head>
<body>
	<a href="hml/nuevo.php">Nuevo</a>	
	<a href="hml/Ver.php">Ver</a>
	<a href="hml/Buscar.php">Buscar</a>
	<a href="identificacion.php">Logout</a>
</body>
</html>